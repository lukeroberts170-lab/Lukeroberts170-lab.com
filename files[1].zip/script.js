document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    // Simulate sending message
    document.getElementById('form-status').textContent = "Thank you for contacting us! We'll get back to you soon.";
    this.reset();
});

// Geolocation for user location map
document.getElementById('show-location').addEventListener('click', function() {
    var locationDiv = document.getElementById('user-location');
    locationDiv.innerHTML = "Locating...";
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            var lat = position.coords.latitude;
            var lon = position.coords.longitude;
            locationDiv.innerHTML = `
                <p>Your location:</p>
                <iframe
                    width="100%" height="250"
                    style="border:0; border-radius:8px"
                    src="https://maps.google.com/maps?q=${lat},${lon}&z=15&output=embed" allowfullscreen loading="lazy"></iframe>
                <p>Latitude: ${lat.toFixed(5)}, Longitude: ${lon.toFixed(5)}</p>
            `;
        }, function() {
            locationDiv.innerHTML = "Unable to retrieve your location.";
        });
    } else {
        locationDiv.innerHTML = "Geolocation is not supported by your browser.";
    }
});